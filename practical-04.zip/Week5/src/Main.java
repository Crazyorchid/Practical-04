public class Main {
    public static void main(String[] args) {
        Referee ref = new Referee();

        ref.judge();

    }
}
